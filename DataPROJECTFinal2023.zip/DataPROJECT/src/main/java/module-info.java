module com.example.dataproject {
    requires javafx.controls;
    requires javafx.fxml;
    requires java.sql;
    requires javafx.graphics;

    opens com.example.dataproject to javafx.fxml;
    exports com.example.dataproject;
}